### jQuery Rotate

Simple plugin that add rotate css property and animation

### Usage

$('.selector').css('rotate', 45);

$('.selector').animate({rotate: '360'}, 2000);

### Demo

<http://jquery.jcubic.pl/rotate.php>

### License

Licensed under [GNU LGPL Version 3 license](http://www.gnu.org/licenses/lgpl.html)

Copyright (c) 2011-2013 [Jakub Jankiewicz](http://jcubic.pl)
